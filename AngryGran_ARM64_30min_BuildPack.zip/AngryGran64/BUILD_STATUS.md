# Angry Gran ARM64 reconstruction status

## Phase 2 — playable gameplay loop

The ARM64 Xcode project now contains a native playable reconstruction loop built around the recovered Angry Gran resources. The original ARMv7 executable remains preserved as `AngryGran.original.armv7` for reference.

Implemented in this pass:
- ARM64 target configuration.
- Recovered resources packaged into the app.
- Recovered main-menu artwork.
- Playable GameScene-style loop with score, distance and cash HUD.
- Moving tap targets and hit scoring.
- Pause/resume and return-to-menu controls.
- Recovered scene names/resources remain available for subsequent reconstruction.

## Next reconstruction pass

The remaining work is to replace the prototype target visuals/physics with the original character and weapon animation data from the recovered Cocos2D/PVR resources, then wire the recovered weapon, level, pension and shop data into native implementations.

This project cannot be compiled into an IPA inside this Linux environment because Apple's iOS SDK/Xcode toolchain is required. The project is structured for ARM64 Xcode builds.
