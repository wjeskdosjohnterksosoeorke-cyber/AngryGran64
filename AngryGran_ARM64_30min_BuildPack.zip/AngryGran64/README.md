# Angry Gran ARM64 Reconstruction

This is the current ARM64 reconstruction workspace for the recovered Angry Gran iOS app.

## Current phase
The project is a native ARM64 iOS application shell that packages the recovered game resources and exposes the recovered major scenes through a working menu.

The original executable is included as `AngryGran.original.armv7` for reference. It is not converted or relinked; its machine code cannot simply be changed from ARMv7 to ARM64.

## Next phase
Reimplement the original game logic and scene behavior using the recovered class/resource inventory, then build and test the resulting ARM64 app on a compatible iOS device.


## Fast cloud build
See `BUILD_NOW.md`. A GitHub Actions macOS workflow is included in `.github/workflows/build-arm64.yml` and produces an unsigned ARM64 IPA suitable for signing in ESign.
