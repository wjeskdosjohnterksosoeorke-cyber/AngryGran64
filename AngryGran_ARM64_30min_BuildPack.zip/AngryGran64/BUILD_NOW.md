# BUILD NOW — fastest route

1. Put this project in a GitHub repository.
2. Open **Actions** → **Build Angry Gran ARM64** → **Run workflow**.
3. Wait for the macOS build to finish.
4. Open the completed run and download artifact **AngryGran-ARM64-IPA**.
5. The artifact is an **unsigned ARM64 IPA**. Import it into ESign (or another signer) with your valid signing certificate, then install it on the iPhone.

The workflow intentionally disables Apple code signing so the build can complete without putting a certificate in GitHub secrets.
