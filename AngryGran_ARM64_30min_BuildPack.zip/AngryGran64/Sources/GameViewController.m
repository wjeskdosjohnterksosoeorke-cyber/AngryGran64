#import "GameViewController.h"

@interface GameViewController ()
@property(nonatomic,strong) UIImageView *backgroundView;
@property(nonatomic,strong) UIView *hud;
@property(nonatomic,strong) UILabel *scoreLabel;
@property(nonatomic,strong) UILabel *distanceLabel;
@property(nonatomic,strong) UILabel *cashLabel;
@property(nonatomic,strong) UIButton *backButton;
@property(nonatomic,strong) UIButton *pauseButton;
@property(nonatomic,strong) NSMutableArray<UIView *> *targets;
@property(nonatomic,strong) NSTimer *gameTimer;
@property(nonatomic,assign) NSInteger score;
@property(nonatomic,assign) NSInteger distance;
@property(nonatomic,assign) NSInteger cash;
@property(nonatomic,assign) BOOL playing;
@property(nonatomic,assign) BOOL paused;
@end

@implementation GameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.blackColor;
    [self buildMainMenu];
}

- (UIImage *)resourceImage:(NSString *)name extension:(NSString *)extension {
    NSString *path = [[NSBundle mainBundle] pathForResource:name ofType:extension inDirectory:@"Resources"];
    return path ? [UIImage imageWithContentsOfFile:path] : nil;
}

- (UIButton *)buttonWithTitle:(NSString *)title action:(SEL)action y:(CGFloat)y {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(0, y, 250, 54);
    button.center = CGPointMake(CGRectGetMidX(self.view.bounds), y + 27);
    button.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin;
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont boldSystemFontOfSize:24.0];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.backgroundColor = [UIColor colorWithWhite:0 alpha:0.65];
    button.layer.cornerRadius = 10.0;
    button.layer.borderWidth = 2.0;
    button.layer.borderColor = UIColor.whiteColor.CGColor;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)buildMainMenu {
    UIImage *background = [self resourceImage:@"mainMenuBackground-hd" extension:@"jpg"];
    if (background) {
        self.backgroundView = [[UIImageView alloc] initWithImage:background];
        self.backgroundView.frame = self.view.bounds;
        self.backgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.backgroundView.contentMode = UIViewContentModeScaleAspectFill;
        [self.view addSubview:self.backgroundView];
    }
    UIView *shade = [[UIView alloc] initWithFrame:self.view.bounds];
    shade.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    shade.backgroundColor = [UIColor colorWithWhite:0 alpha:0.25];
    [self.view addSubview:shade];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0, 35, self.view.bounds.size.width, 70)];
    title.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    title.text = @"ANGRY GRAN";
    title.textAlignment = NSTextAlignmentCenter;
    title.font = [UIFont boldSystemFontOfSize:42.0];
    title.textColor = UIColor.whiteColor;
    title.shadowColor = UIColor.blackColor;
    title.shadowOffset = CGSizeMake(2, 2);
    [self.view addSubview:title];

    UIView *menu = [[UIView alloc] initWithFrame:self.view.bounds];
    menu.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:menu];
    [menu addSubview:[self buttonWithTitle:@"PLAY" action:@selector(playPressed:) y:130]];
    [menu addSubview:[self buttonWithTitle:@"SHOP" action:@selector(shopPressed:) y:195]];
    [menu addSubview:[self buttonWithTitle:@"STATISTICS" action:@selector(statsPressed:) y:260]];
    [menu addSubview:[self buttonWithTitle:@"PENSION" action:@selector(pensionPressed:) y:325]];
}

- (void)playPressed:(id)sender {
    [self startGame];
}
- (void)shopPressed:(id)sender { [self showInfo:@"SHOP" message:@"Weapon shop scene recovered. Weapon data and purchase menus are included in the project; the next reconstruction pass can wire the individual weapons."]; }
- (void)statsPressed:(id)sender { [self showInfo:@"STATISTICS" message:[NSString stringWithFormat:@"Score: %ld\nDistance: %ld m\nCash: %ld", (long)self.score, (long)self.distance, (long)self.cash]]; }
- (void)pensionPressed:(id)sender { [self showInfo:@"PENSION" message:@"Pension scene recovered. Your run cash will be tracked here in the reconstruction."]; }

- (void)showInfo:(NSString *)title message:(NSString *)message {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

#pragma mark - Gameplay reconstruction

- (void)startGame {
    self.playing = YES; self.paused = NO; self.score = 0; self.distance = 0; self.cash = 0;
    self.targets = [NSMutableArray array];
    [self.view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    UIImage *bg = [self resourceImage:@"mainMenuBackground-hd" extension:@"jpg"];
    self.backgroundView = [[UIImageView alloc] initWithImage:bg];
    self.backgroundView.frame = self.view.bounds;
    self.backgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.backgroundView.contentMode = UIViewContentModeScaleAspectFill;
    [self.view addSubview:self.backgroundView];

    self.hud = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 64)];
    self.hud.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    self.hud.backgroundColor = [UIColor colorWithWhite:0 alpha:0.55];
    [self.view addSubview:self.hud];
    self.scoreLabel = [self hudLabel:@"SCORE 0" frame:CGRectMake(15, 8, 180, 45)];
    self.distanceLabel = [self hudLabel:@"DISTANCE 0m" frame:CGRectMake(195, 8, 190, 45)];
    self.cashLabel = [self hudLabel:@"£0" frame:CGRectMake(385, 8, 80, 45)];
    [self.hud addSubview:self.scoreLabel]; [self.hud addSubview:self.distanceLabel]; [self.hud addSubview:self.cashLabel];

    self.backButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.backButton.frame = CGRectMake(10, self.view.bounds.size.height-60, 95, 45);
    self.backButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin;
    [self.backButton setTitle:@"MENU" forState:UIControlStateNormal];
    self.backButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    [self.backButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.backButton.backgroundColor = [UIColor colorWithWhite:0 alpha:.65];
    self.backButton.layer.cornerRadius = 8;
    [self.backButton addTarget:self action:@selector(endGame) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.backButton];

    self.pauseButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.pauseButton.frame = CGRectMake(self.view.bounds.size.width-105, self.view.bounds.size.height-60, 95, 45);
    self.pauseButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin;
    [self.pauseButton setTitle:@"PAUSE" forState:UIControlStateNormal];
    self.pauseButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    [self.pauseButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.pauseButton.backgroundColor = [UIColor colorWithWhite:0 alpha:.65];
    self.pauseButton.layer.cornerRadius = 8;
    [self.pauseButton addTarget:self action:@selector(togglePause) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.pauseButton];

    [self spawnTarget:nil]; [self spawnTarget:nil];
    self.gameTimer = [NSTimer scheduledTimerWithTimeInterval:.08 target:self selector:@selector(gameTick:) userInfo:nil repeats:YES];
}

- (UILabel *)hudLabel:(NSString *)text frame:(CGRect)frame {
    UILabel *l = [[UILabel alloc] initWithFrame:frame];
    l.text = text; l.textColor = UIColor.whiteColor; l.font = [UIFont boldSystemFontOfSize:17];
    l.textAlignment = NSTextAlignmentCenter; return l;
}

- (void)spawnTarget:(NSTimer *)timer {
    if (!self.playing || self.paused) return;
    CGFloat w = 62, h = 82;
    CGFloat x = self.view.bounds.size.width + 20;
    CGFloat y = 115 + arc4random_uniform((uint32_t)MAX(1, (int)self.view.bounds.size.height-220));
    UIView *target = [[UIView alloc] initWithFrame:CGRectMake(x,y,w,h)];
    target.backgroundColor = [UIColor colorWithWhite:.08 alpha:.92];
    target.layer.cornerRadius = 24;
    target.layer.borderWidth = 3;
    target.layer.borderColor = UIColor.whiteColor.CGColor;
    target.tag = 1001;
    UILabel *head = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 42, 42)];
    head.text = @"👤"; head.font = [UIFont systemFontOfSize:34]; head.textAlignment = NSTextAlignmentCenter;
    [target addSubview:head];
    UILabel *tap = [[UILabel alloc] initWithFrame:CGRectMake(0, 48, 62, 24)];
    tap.text = @"SMASH"; tap.textColor = UIColor.whiteColor; tap.font = [UIFont boldSystemFontOfSize:11]; tap.textAlignment = NSTextAlignmentCenter;
    [target addSubview:tap];
    target.userInteractionEnabled = YES;
    [self.view addSubview:target]; [self.targets addObject:target];
    UITapGestureRecognizer *g = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(targetTapped:)];
    [target addGestureRecognizer:g];
}

- (void)targetTapped:(UITapGestureRecognizer *)g {
    if (self.paused || !self.playing) return;
    UIView *t = g.view;
    self.score += 100; self.cash += 1;
    [self.targets removeObject:t];
    [UIView animateWithDuration:.12 animations:^{ t.transform = CGAffineTransformMakeScale(1.5,1.5); t.alpha=0; } completion:^(BOOL done){ [t removeFromSuperview]; }];
    [self updateHUD];
}

- (void)gameTick:(NSTimer *)timer {
    if (!self.playing || self.paused) return;
    self.distance += 1;
    for (UIView *t in [self.targets copy]) {
        t.center = CGPointMake(t.center.x - 5.0, t.center.y);
        if (CGRectGetMaxX(t.frame) < -20) { [self.targets removeObject:t]; [t removeFromSuperview]; }
    }
    if (arc4random_uniform(100) < 4) [self spawnTarget:nil];
    [self updateHUD];
}

- (void)updateHUD {
    self.scoreLabel.text = [NSString stringWithFormat:@"SCORE %ld", (long)self.score];
    self.distanceLabel.text = [NSString stringWithFormat:@"DISTANCE %ldm", (long)self.distance];
    self.cashLabel.text = [NSString stringWithFormat:@"£%ld", (long)self.cash];
}

- (void)togglePause {
    self.paused = !self.paused;
    [self.pauseButton setTitle:(self.paused ? @"RESUME" : @"PAUSE") forState:UIControlStateNormal];
}

- (void)endGame {
    [self.gameTimer invalidate]; self.gameTimer = nil; self.playing = NO;
    [self.targets makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self.view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self buildMainMenu];
}

- (BOOL)prefersStatusBarHidden { return YES; }
@end
