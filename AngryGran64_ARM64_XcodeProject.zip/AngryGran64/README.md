# Angry Gran ARM64 Reconstruction Workspace

Generated directly from the supplied decrypted IPA.

Included:
- Original app resources
- Original Info.plist
- Original ARMv7 executable preserved for reverse-engineering reference
- Recovered Objective-C class inventory and stubs
- ARM64 Xcode build configuration
- Reconstruction manifest

The ARMv7 executable is reference material only. A real ARM64 executable requires recompilation/reimplementation of the original code with an iOS SDK.
