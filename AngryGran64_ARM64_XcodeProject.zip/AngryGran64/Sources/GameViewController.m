#import "GameViewController.h"
@interface GameViewController ()
@property(nonatomic,strong) UILabel *label;
@end
@implementation GameViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    self.label = [[UILabel alloc] initWithFrame:self.view.bounds];
    self.label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.label.textAlignment = NSTextAlignmentCenter;
    self.label.textColor = [UIColor whiteColor];
    self.label.text = @"Angry Gran — ARM64 reconstruction";
    self.label.numberOfLines = 0;
    [self.view addSubview:self.label];
}
@end
