#import "AppDelegate.h"
#import "GameViewController.h"
@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [GameViewController new];
    [self.window makeKeyAndVisible];
    return YES;
}
@end
