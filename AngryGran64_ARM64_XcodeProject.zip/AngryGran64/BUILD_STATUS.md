# Angry Gran ARM64 build status

This workspace now contains a native ARM64 Xcode application shell and the recovered Angry Gran resources/classes.

The shell is intentionally compile-safe and does not pretend the original ARMv7 machine code was converted. The original executable is retained separately for reverse-engineering reference.

Next reconstruction work: replace the placeholder UIKit screen with implementations of the recovered game scenes and Cocos2D-compatible behavior while preserving the original resources.
